package com.badlogic.game;

import com.badlogic.drop.FoodManager;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;


public class BottomBun {
    Array<String> Order;
    com.badlogic.game.Food food; // bun
    FoodManager foodManager; // other foods
    Array<com.badlogic.game.Food> caughtFoods;
    Sound welldone;
    Sound wrong;
    float speed;
    float topBunTimer;
    float topBunTime;
    public int x;
    Array<String> orderArray;
    Texture order;
    Sprite os;
    public int numberoforders;
    public int numberoflives;
    Sprite ordernumbersprite;
    public int correct;

    public BottomBun(FoodManager foodManager,int a) {
        x=0;
        int correct =0;
        this.foodManager = foodManager;

        caughtFoods = new Array<com.badlogic.game.Food>();

        food = new com.badlogic.game.Food("bottom_bun.png", "bun");
        food.hitBox.x = Gdx.graphics.getWidth() / 2;
        food.hitBox.y = Gdx.graphics.getHeight() - 80;
        food.sprite.setScale(6); // make bun bigger
        food.hitBox.width = food.sprite.getWidth() * food.sprite.getScaleX(); // fix width of hitbox
        food.hitBox.height = 6 * food.sprite.getScaleY(); // bun is 6 pixels high
        speed = 10;
        x = a;
        FoodManager fm = new FoodManager();
        Order = foodManager.makeOrder(x);
        caughtFoods.add(food);
        welldone = Gdx.audio.newSound(Gdx.files.internal("Welldone.mp3"));
        wrong = Gdx.audio.newSound(Gdx.files.internal("Wrong.mp3"));
        numberoforders =3;
        numberoflives=3;
    }


    public void update() {


        // movement
        food.dx = 0;

        if (Gdx.input.isKeyPressed(Input.Keys.LEFT) || Gdx.input.isKeyPressed(Input.Keys.Q)) {
            food.dx = -speed;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT) || Gdx.input.isKeyPressed(Input.Keys.P)) {
            food.dx = speed;
        }


        food.update();


        // collect food
        for (int i = 0; i < foodManager.foodArray.size; i++) {
            if (caughtFoods.get(caughtFoods.size - 1).hitBox.overlaps(foodManager.foodArray.get(i).hitBox)) {
                foodManager.foodArray.get(i).active = false;
                caughtFoods.add(foodManager.foodArray.get(i));
            }
        }


        // manage caught foods
        // caughtFood[0] is the bun, so i is 1
        for (int i = 1; i < caughtFoods.size; i++) {
            caughtFoods.get(i).hitBox.x = food.hitBox.x + food.hitBox.width / 2 - caughtFoods.get(i).hitBox.width / 2;
            caughtFoods.get(i).hitBox.y = food.hitBox.y - i * caughtFoods.get(i).hitBox.height / 2.5f;
            if (caughtFoods.get(i).name.equals("top bun")) { // adjust height of top bun
                caughtFoods.get(i).hitBox.y += caughtFoods.get(i).hitBox.height / 2f;
                if(compare()==true){
                    welldone.play();
                    x++;//increment number of ingridients
                    Order = foodManager.makeOrder(x);
                    correct++;
                    numberoforders--;
                }else{
                    wrong.play();
                    numberoflives--;
                }

                //comapare method call goes here
            }
            caughtFoods.get(i).sprite.setPosition(caughtFoods.get(i).hitBox.x, caughtFoods.get(i).hitBox.y);
        }

        if (caughtFoods.get(caughtFoods.size - 1).name.equals("top bun")) {
            while (caughtFoods.size > 1) {
                caughtFoods.removeIndex(caughtFoods.size - 1);
            }
        }

    }
    public boolean compare(){

        if(caughtFoods.size-2 == Order.size){
          //  System.out.println(Order.size);
            Array<String> compare = new Array<String>();
            Array<String> compare2 = new Array<String>();
            for(int i =1; i <= (Order.size); i++) {
                compare.add(caughtFoods.get(i).name);
                compare2.add(Order.get(i-1).substring(0,Order.get(i-1).length()-4));
               // System.out.println(compare2.get(i-1));
              //  System.out.println(compare.get(i-1));
            }

            compare.sort();
            compare2.sort();
            if(compare.equals(compare2)){
               // System.out.print("Works");//test
                return true;
            }
        }
       // System.out.println("Not working");//test
        return false;
    }

    public void draw(SpriteBatch batch) {
        int y = 70;
        for (int j = 0; j < Order.size; j++) {
            order = new Texture(Order.get(j));
            os = new Sprite(order);
            os.setPosition(50, y);
            os.setSize(20, 20);
            os.draw(batch);
            y = y + 25;
            for (int i = 0; i < caughtFoods.size; i++) {
                caughtFoods.get(i).draw(batch);
            }

        }
        // compare method goes here
    }
}
