package com.badlogic.drop;
import java.util.*;
import java.util.Iterator;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;
import com.badlogic.gdx.graphics.g2d.BitmapFont;


public class GameScreenLevel2 implements Screen {
    final Drop game;
    OrthographicCamera camera;
    SpriteBatch batch;
    FoodManager foodManager2;
    com.badlogic.game.BottomBun bottomBun2;
    Sprite backgroundSprite;
    Texture backgroundTexture;
    Boolean ispaused;
    // Sprite demo
    int framecount = 1;
    int incr = 1;
    Array<String> Order = new Array<String>();
    Texture order;
    Sprite os;
    Texture ordersheet;
    Sprite ordersheetsprite;
    Sprite sprite;
    BitmapFont defaultSmall;

    public GameScreenLevel2(final Drop gam) {
        ispaused= false;
        game= gam;
        Gdx.graphics.setWindowedMode(700, 900);
        camera = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.setToOrtho(true,700,900);
        foodManager2 = new FoodManager();
        bottomBun2 = new com.badlogic.game.BottomBun(foodManager2,2);
        backgroundTexture= new Texture("background.jpg");
        backgroundSprite = new Sprite(backgroundTexture);
        batch = new SpriteBatch();



    }

    @Override
    public void render (float delta) {

        camera.update();
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        foodManager2.update();
        bottomBun2.update();

        batch.begin();
        ordersheet = new Texture("paper.png");
        backgroundSprite.draw(batch);
        ordersheetsprite = new Sprite(ordersheet);
        ordersheetsprite.setPosition(5, 1);
        ordersheetsprite.setSize(100, 250);
        ordersheetsprite.draw(batch);
        foodManager2.draw(batch);
        bottomBun2.draw(batch);
        defaultSmall = new BitmapFont(true);

        defaultSmall.draw(batch, "Number Of Orders: " + bottomBun2.numberoforders , 0, 5);
        defaultSmall.draw(batch,"Press B to go to main menu", 200,5);
        defaultSmall.draw(batch, "Number Of Lives: " + bottomBun2.numberoflives , 500, 5);
        batch.end();

        batch.setProjectionMatrix(camera.combined);

        if (Gdx.input.isKeyPressed(Input.Keys.B)) {
            this.game.setScreen(new MainMenu(game));
            this.dispose();
            Gdx.graphics.setWindowedMode(800, 480);


        }
        if(bottomBun2.correct>2){
            this.game.setScreen(new NextLevel2(game));
            Gdx.graphics.setWindowedMode(800, 480);
        }
        if(bottomBun2.numberoflives==0){
            this.game.setScreen(new LoseScreen(game));
            Gdx.graphics.setWindowedMode(800, 480);
        }

    }




    public void resize(int width, int height) {
    }

    public void show() {
    }

    public void hide() {
    }

    public void pause() {
    }

    public void resume() {
    }

    public void dispose() {
    }
}
